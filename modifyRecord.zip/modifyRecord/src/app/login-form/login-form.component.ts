import { Component, OnInit } from '@angular/core';
//import { Router } from '@angular/router';

import { Login } from '../model/login';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  model = new Login();
  submitted = false;

  constructor() { }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
    console.log(JSON.stringify(this.model));
    //this.router.navigateByUrl('retrievePage');
  }

}
