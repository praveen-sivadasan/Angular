import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginFormComponent } from './login-form/login-form.component';
import { RetrievePageComponent } from './retrieve-page/retrieve-page.component';

const appRoutes: Routes = [
    { path: 'loginForm', component: LoginFormComponent },
    { path: 'retrievePage', component: RetrievePageComponent },
    { path: '', redirectTo: 'loginForm', pathMatch: 'full' },
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);