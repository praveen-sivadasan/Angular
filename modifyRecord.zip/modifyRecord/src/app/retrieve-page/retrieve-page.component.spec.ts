import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RetrievePageComponent } from './retrieve-page.component';

describe('RetrievePageComponent', () => {
  let component: RetrievePageComponent;
  let fixture: ComponentFixture<RetrievePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RetrievePageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetrievePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
