import { Component, OnInit } from '@angular/core';
import { UserProfile } from '../model/user-profile';
import { UserService } from '../service/user.service';
import { Item } from '../model/item';

@Component({
  selector: 'app-retrieve-page',
  templateUrl: './retrieve-page.component.html',
  styleUrls: ['./retrieve-page.component.css']
})
export class RetrievePageComponent implements OnInit {

  userProfile = new UserProfile();
  foodList : Item[];
  drinkList : Item[];
  selectedItemList : Item[];

  constructor(user_service: UserService) {
    this.selectedItemList = new Array<Item>(3);
    this.getUserProfile(user_service);
    console.log(this.userProfile.flight.inventory_drink_list);
    console.log(this.userProfile.flight.inventory_food_list);

   }

  ngOnInit() {
  }

  getUserProfile(user_service: UserService): void{
    this.userProfile = user_service.getUserProfile('ABCDE');
  }

  selectItem(category: string, selectedItem: Item) : void {
    if (selectedItem.selectedQuantity < selectedItem.quantity) {
      selectedItem.selectedQuantity = selectedItem.selectedQuantity + 1;
    }
  } 

  removeItem(category: string, selectedItem: Item) : void {
    if (selectedItem.selectedQuantity > 0) {
      selectedItem.selectedQuantity = selectedItem.selectedQuantity - 1;
    }
  } 

}
