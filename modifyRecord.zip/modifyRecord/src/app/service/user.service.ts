import { Injectable } from '@angular/core';
import { UserProfile } from '../model/user-profile';
import { InventoryService } from './inventory.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  user_profile_list: UserProfile[];

  constructor(private inventory_service: InventoryService) { 
    this.user_profile_list = [];

    let a = new UserProfile();
    a.first_name = 'James';
    a.last_name = 'Ludwig';
    a.rec_loc = 'ABCDE';
    a.flight_num = 'A237';
    a.seat = '20C';
    a.flight = inventory_service.getFlightInventory(a.flight_num);

    this.user_profile_list[0] = a;
  }

  getUserProfile(rec_loc: string) : UserProfile {
    // TODO logic to verify record locator
    return this.user_profile_list[0];
  }
}
