import { Injectable } from '@angular/core';
import { Flight } from '../model/flight';
import { Item } from '../model/item';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  flightList: Flight[];
  
  itemTypeDrink = 'Drinks';
  itemTypeFood = 'Food';

  constructor() { 
   this.flightList = [];

    let aFlight = new Flight();
    aFlight.flight_num = 'A237';
    let inventory_drink_list = [];
    let inventory_food_list = [];

    let itema = new Item();
    itema.type= this.itemTypeDrink;
    itema.name='Bud Light';
    itema.quantity = 20;
    itema.selectedQuantity = 0;
    itema.price=10;
    inventory_drink_list[0] = itema;

    let itemb = new Item();
    itemb.type= this.itemTypeDrink;
    itemb.name='Coors';
    itemb.quantity = 30;
    itemb.selectedQuantity = 0;
    itemb.price=10;
    inventory_drink_list[1] = itemb;

    let itemc = new Item();
    itemc.type= this.itemTypeFood;
    itemc.name='Pasta';
    itemc.quantity = 22;
    itemc.selectedQuantity = 0;
    itemc.price=15.50;
    inventory_food_list[0] = itemc;

    let itemd = new Item();
    itemd.type= this.itemTypeFood;
    itemd.name='Omlete';
    itemd.quantity = 29;
    itemd.selectedQuantity = 0;
    itemd.price=9.50;
    inventory_food_list[1] = itemd;

    aFlight.inventory_food_list = inventory_food_list;
    aFlight.inventory_drink_list = inventory_drink_list;
    aFlight.inventory_order_list = [];
    this.flightList[0] = aFlight;
  }

  getFlightInventory(number:string): Flight {
    // TODO can check to get inventory of a particular flight
    return this.flightList[0];
  }


}
