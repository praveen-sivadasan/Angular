export class Item {
    public type: string;
    public id : string;
    public quantity: number;
    public selectedQuantity: number;
    public name: string;
    public price:number;
}
