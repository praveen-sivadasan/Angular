import { Flight } from './flight';

export class UserProfile {

    public rec_loc: string;
    public first_name: string;
    public last_name: string;
    public seat: string;
    public flight_num: string;

    public flight: Flight;

    constructor(
        ) { }

}
