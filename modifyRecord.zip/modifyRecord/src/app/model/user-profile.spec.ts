import { UserProfile } from './user-profile';

describe('UserProfile', () => {
  it('should create an instance', () => {
    expect(new UserProfile()).toBeTruthy();
  });
});
