export class Login {

  public rec_loc: string;
  public last_name: string;

  constructor(
  ) { }
}
