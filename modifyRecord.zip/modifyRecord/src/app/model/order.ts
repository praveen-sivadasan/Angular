export class Order {
    public item_name: string;
    public seat: string;
    public itemType: string;
    public status: string;
}
