import { Item } from './item';
import { Order } from './order';

export class Flight {
    public flight_num: string;
    public inventory_food_list: Item[];
    public inventory_drink_list: Item[];

    public inventory_order_list: Order[];

}
